# Update GitHub and Google Drive

## GitHub

1. Extract `Listening-Post-LPOS-v2.0.zip`.
2. Open the existing GitHub `lpos` repository.
3. Select **Add file**, then **Upload files**.
4. Select everything inside the extracted folder.
5. Drag it into GitHub.
6. Commit with:

```text
Upgrade LPOS to complete v2 quality system
```

## Google Drive

To keep the existing share link:

1. Find the current LPOS ZIP.
2. Right-click it.
3. Select **Manage versions**.
4. Select **Upload new version**.
5. Choose `Listening-Post-LPOS-v2.0.zip`.
