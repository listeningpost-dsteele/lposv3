---
id: ADR-0003
title: Evidence Engine Replaces Money Mission
status: Accepted
date: 2026-07-18
owner: Listening Post
---

# Decision

Evidence Engine is the constitutional measurement system. Revenue is one evidence
stream among time, quality, operational, strategic, and learning outcomes.
