---
id: ADR-0001
title: Single Principal
status: Accepted
date: 2026-07-18
owner: Listening Post
---

# Context

LPOS required a canonical authority and context model.

# Decision

LPOS serves exactly one Principal.

# Consequences

The Principal Model, Chip, permissions, and decision hierarchy remain simple and
coherent. Team and organization support may be composed around the Principal later.
