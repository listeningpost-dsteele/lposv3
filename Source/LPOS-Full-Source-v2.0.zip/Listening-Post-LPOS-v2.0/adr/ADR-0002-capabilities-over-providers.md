---
id: ADR-0002
title: Capabilities Over Providers
status: Accepted
date: 2026-07-18
owner: Listening Post
---

# Decision

Architectural components request capabilities. Runtime configuration selects
providers.

# Consequences

OpenAI, GLM, Ollama, Hermes, Watt, and other implementations may change without
rewriting LPOS.
