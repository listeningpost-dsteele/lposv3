---
id: LPOS-021
title: Document Standard
version: 1.0.0
status: Accepted
classification: Governance
owner: Listening Post
---

# Document Standard

Documents use YAML front matter and human-readable Markdown.

Humans edit one source file. Machines consume structured front matter and embedded
schemas or generated artifacts.

Required sections are Purpose, Scope, Mission, Main Content, Conformance, Non-Goals,
References, and Revision History.
