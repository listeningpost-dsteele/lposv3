# Install LPOS in Hermes Agent

This project supports two practical installation methods.

## Method 1: Copy the LPOS skills into Hermes

This is the fastest local installation.

### macOS or Linux

1. Open Terminal.
2. Change into the extracted project folder. Example:

```bash
cd ~/Downloads/Listening-Post-Complete
```

3. Run:

```bash
mkdir -p ~/.hermes/skills/listening-post
cp -R skills/listening-post/* ~/.hermes/skills/listening-post/
```

4. Confirm the installation:

```bash
hermes skills list
```

5. Start a new Hermes session. Installed skills take effect in new sessions.
6. Test the core:

```text
/lpos-core Review this project and tell me the next completed deliverable.
```

7. Test Opportunity Intelligence:

```text
/opportunity-intelligence Find and validate three high-value opportunities for Listening Post.
```

### Windows PowerShell

From the extracted project directory:

```powershell
New-Item -ItemType Directory -Force "$HOME\.hermes\skills\listening-post"
Copy-Item -Recurse -Force ".\skills\listening-post\*" "$HOME\.hermes\skills\listening-post\"
hermes skills list
```

Then start a new Hermes session.

## Method 2: Install the skills from your GitHub repository

After the repository is on GitHub:

```bash
hermes skills tap add YOUR-GITHUB-NAME/lpos
```

Hermes taps expect a `skills/` directory. This repository includes one.

Install an individual skill:

```bash
hermes skills install YOUR-GITHUB-NAME/lpos/skills/listening-post/lpos-core
hermes skills install YOUR-GITHUB-NAME/lpos/skills/listening-post/opportunity-intelligence
hermes skills install YOUR-GITHUB-NAME/lpos/skills/listening-post/executive-brief
```

If a direct path is not accepted by your Hermes build, use Method 1. It works by copying
the standard `SKILL.md` folders into `~/.hermes/skills/`.

## Give Hermes the Principal Model

1. Open `examples/principal-model.example.yaml`.
2. Fill in only durable facts and preferences.
3. Do not enter passwords, API keys, or secrets.
4. Save it as `principal-model.yaml`.
5. Put it in a directory Hermes can read during your work.

For project-local use, keep it in the repository and start Hermes from the repository
directory.

## Run Hermes inside the project

From Terminal:

```bash
cd /path/to/Listening-Post-Complete
hermes chat
```

When Hermes runs in the project directory, project files are available to its file tools.

## Create the Opportunity Intelligence scheduled job

First make sure the Hermes gateway scheduler is running:

```bash
hermes gateway install
hermes cron status
```

Create a job:

```bash
hermes cron create "every 1d at 22:00"   "Use the opportunity-intelligence skill. Review current technical, open-source, research, standards, customer, and internal signals. Reject hype and obvious news. Deliver one consolidated executive brief with Reject, Watch, Experiment, and Implement recommendations. Include evidence, implementation, expected value, measurement plan, decision requested, and confidence."   --skill opportunity-intelligence   --name "Opportunity Intelligence"   --workdir "$PWD"
```

Test it immediately:

```bash
hermes cron list
hermes cron run "Opportunity Intelligence"
```

## Create the Executive Brief scheduled job

```bash
hermes cron create "every 1d at 22:00"   "Use the executive-brief skill. Review active initiatives, decisions, evidence, risks, opportunities, calendar, and Standing Operation health. Produce a concise tomorrow-focused executive brief. Include only information that changes a decision, priority, preparation requirement, or risk."   --skill executive-brief   --name "Executive Brief"   --workdir "$PWD"
```

## Important cron rule

Hermes cron jobs run in fresh sessions. Their prompts must be self-contained or attach
the required skills. Using `--workdir` also gives the job access to the project files.

## Verify

```bash
hermes skills list
hermes cron list
hermes cron status
```

You should see the LPOS skills and both scheduled jobs.
