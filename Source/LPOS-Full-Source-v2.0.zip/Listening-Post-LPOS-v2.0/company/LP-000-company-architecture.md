---
id: LP-000
title: Company Architecture
version: 0.1.0
status: Draft
owner: Listening Post
---

# Listening Post Company Architecture

## Purpose

Listening Post helps people and organizations create measurable value through better
intelligence, better decisions, and better execution.

## Architecture

Mission

↓

Capabilities

↓

Products

↓

Operating systems

↓

Infrastructure

## Products

- Listening Post Platform
- Audienc3
- LPOS Desktop
- Conjur3

## Infrastructure

Infrastructure is replaceable. Current examples include Hermes, OpenAI, GLM, Ollama,
local compute, cloud services, and licensed data providers.

## Product rule

Listening Post products may enhance LPOS. They shall not be required for LPOS to
provide genuine value.

## Evidence

Every important claim should become measurable evidence.

## Revision history

| Version | Date | Notes |
|---|---|---|
| 0.1.0 | 2026-07-18 | Initial draft |
