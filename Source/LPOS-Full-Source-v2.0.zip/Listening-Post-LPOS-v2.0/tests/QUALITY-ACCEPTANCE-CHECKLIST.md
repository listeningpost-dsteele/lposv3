# LPOS v2 Acceptance Checklist

- [ ] Every specialist has one or more craft standards.
- [ ] Every material workflow uses an independent reviewer.
- [ ] Existing approved artifacts are baselined before changes.
- [ ] Public copy contains no internal reasoning.
- [ ] Visual work is reviewed as rendered desktop and mobile.
- [ ] Research separates fact, inference, forecast, and speculation.
- [ ] Strategy contains real alternatives and invalidation conditions.
- [ ] Engineering is executed and tested in the real environment.
- [ ] Security boundaries and external action gates remain intact.
- [ ] Finance separates actuals, estimates, forecasts, and scenarios.
- [ ] Legal work states jurisdiction and limitations.
- [ ] Data work defines metrics, lineage, denominator, and quality.
- [ ] Automation is idempotent, observable, recoverable, and tested.
- [ ] Standing Operations create useful evidence and avoid duplicate noise.
- [ ] Provider routing is capability-based and benchmarked.
- [ ] The Principal approves material taste, brand, strategy, and external actions.
