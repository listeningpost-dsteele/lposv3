from pathlib import Path
import re, sys, yaml

root = Path(__file__).resolve().parents[1]
errors = []

required = [
    root/"lpos/LPOS-026-quality-operating-system.md",
    root/"lpos/LPOS-027-universal-professional-reasoning.md",
    root/"lpos/LPOS-028-specialist-quality-routing.md",
    root/"craft-standards/CRAFT-STANDARD-ROUTING.yaml",
]
for p in required:
    if not p.exists():
        errors.append(f"Missing required file: {p.relative_to(root)}")

specialists = list((root/"specialists").glob("*.md"))
for p in specialists:
    txt = p.read_text()
    if "craft_standards:" not in txt:
        errors.append(f"Missing craft_standards mapping: {p.name}")
    if "## Output contract" not in txt:
        errors.append(f"Missing output contract: {p.name}")

for p in (root/"standing-operations").glob("*.md"):
    txt = p.read_text()
    for marker in ["## Mission", "## Success criteria", "## Failure conditions"]:
        if marker not in txt:
            errors.append(f"{p.name} missing {marker}")

if errors:
    print("\\n".join(errors))
    sys.exit(1)

print(f"PASS: {len(specialists)} specialists mapped and core quality files present.")
