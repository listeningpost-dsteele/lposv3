# Put This Project on GitHub

You do not need to know Git to publish the first version.

## Before starting

1. Download `Listening-Post-LPOS-Complete.zip`.
2. Double-click the ZIP to extract it.
3. Confirm that you can see `README.md`, `START_HERE.md`, and the project folders.

## Create the repository

1. Open GitHub in your browser and sign in.
2. Select the plus sign in the upper-right corner.
3. Select **New repository**.
4. Repository name: `lpos`.
5. Description: `Listening Post Operating System`.
6. Choose **Private** while you are testing it. You can make it public later.
7. Do not add a README, `.gitignore`, or license. They are already in the ZIP.
8. Select **Create repository**.

## Upload the project

1. On the empty repository page, select **uploading an existing file**.
   If that link is not visible, select **Add file**, then **Upload files**.
2. Open the extracted `Listening-Post-Complete` folder.
3. Select everything inside the folder, not the outer folder itself.
4. Drag the selected files and folders onto the GitHub upload page.
5. Wait for all files to finish uploading.
6. In the commit message box, enter:
   `Initial LPOS release`
7. Select **Commit changes**.

## Check the result

The repository home page should display `README.md`. You should also see folders named
`lpos`, `guilds`, `specialists`, `standing-operations`, `skills`, and `runtimes`.

## Make a change later

1. Open a Markdown file on GitHub.
2. Select the pencil icon.
3. Edit the file.
4. Select **Commit changes**.
5. Write a short description and commit directly to `main`.

GitHub preserves each committed version, so you can review or restore earlier work.
