# First Run Checklist

- [ ] Download and extract the ZIP.
- [ ] Read `START_HERE.md`.
- [ ] Create a private GitHub repository.
- [ ] Upload the contents of this folder.
- [ ] Fill in `examples/principal-model.example.yaml`.
- [ ] Install Hermes skills using the script for your operating system.
- [ ] Start a new Hermes session.
- [ ] Run `/lpos-core`.
- [ ] Run `/opportunity-intelligence`.
- [ ] Create and test the Opportunity Intelligence cron job.
- [ ] Create and test the Executive Brief cron job.
- [ ] Commit your populated Principal Model only if it contains no sensitive information.
