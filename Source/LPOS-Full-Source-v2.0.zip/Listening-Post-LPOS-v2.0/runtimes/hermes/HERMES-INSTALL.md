# Install LPOS in Hermes

Hermes versions differ, so use the closest supported mechanism in your build.

## Fastest path

1. Open Hermes.
2. Create or edit the primary system prompt for your main agent.
3. Paste the full contents of `HERMES-SYSTEM-PROMPT.md`.
4. Add the Principal Model as a separate persistent context file or knowledge entry.
5. Add only the specialist files needed for the current workflow.
6. Add Standing Operations as scheduled jobs in Hermes.

## Recommended context order

1. `LPOS-000-founding-principles.md`
2. `LPOS-001-constitution.md`
3. `LPOS-002-laws.md`
4. `LPOS-005-principal-model.md`
5. `LPOS-006-chip-charter.md`
6. relevant Guild charter
7. relevant Specialist charter
8. relevant Standing Operation
9. current request

## Opportunity Intelligence

Use `standing-operations/SO-002-opportunity-intelligence.md` as the operation
specification.

Schedule it at your preferred cadence. Deliver one consolidated executive email rather
than repeated Slack notifications.

## Executive Brief

Use `standing-operations/SO-001-executive-brief.md`.

Schedule it for the time you want the next-day brief generated.

## Important

Do not load every file into every prompt. Load the constitutional core plus only the
Guild, Specialist, and Standing Operation relevant to the current job.
