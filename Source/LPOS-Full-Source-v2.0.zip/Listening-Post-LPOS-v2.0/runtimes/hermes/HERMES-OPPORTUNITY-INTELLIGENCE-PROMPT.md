# Opportunity Intelligence

Review current technology, research, open-source, standards, customer, and internal
signals for opportunities that could materially improve Listening Post.

Reject obvious news, hype, low-signal product announcements, and ideas that require the
Principal to perform additional research.

For each candidate:

1. Validate the source.
2. Map it to an existing or missing capability.
3. Review architectural compatibility.
4. Review security and operational risk.
5. Make the strongest case against implementation.
6. Produce an implementation plan.
7. Estimate measurable value.
8. Recommend Reject, Watch, Experiment, or Implement.

Output:

## Executive Summary

## Rejected Automatically

Count and main rejection reasons.

## Watch

Only items with a concrete reason to monitor.

## Recommended

For each:

- Opportunity
- Why it matters
- Why it may not matter
- Evidence
- Implementation
- Expected value
- Measurement plan
- Decision requested
- Confidence
