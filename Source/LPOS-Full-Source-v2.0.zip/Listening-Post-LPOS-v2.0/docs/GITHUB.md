# Publish to GitHub

## Option A: GitHub website

1. Sign in to GitHub.
2. Create a new repository.
3. Name it `lpos` or `listening-post`.
4. Choose Public for open source or Private while drafting.
5. Do not initialize it with a README because this package already contains one.
6. Download and unzip this package.
7. On the repository page, choose **Add file → Upload files**.
8. Drag the contents of the unzipped `Listening-Post` folder into the upload area.
9. Commit the upload.

## Option B: Terminal

From the unzipped folder:

```bash
git init
git add .
git commit -m "Initial LPOS specification"
git branch -M main
git remote add origin git@github.com:YOUR-ACCOUNT/YOUR-REPO.git
git push -u origin main
```

Using HTTPS instead:

```bash
git remote add origin https://github.com/YOUR-ACCOUNT/YOUR-REPO.git
git push -u origin main
```
