# Use with Hermes

Start with `runtimes/hermes/HERMES-INSTALL.md`.

The fastest working configuration is:

- Main system prompt: `runtimes/hermes/HERMES-SYSTEM-PROMPT.md`
- Opportunity job: `runtimes/hermes/HERMES-OPPORTUNITY-INTELLIGENCE-PROMPT.md`
- Persistent context: `lpos/LPOS-005-principal-model.md`, populated with real data
- Recurring jobs: files under `standing-operations/`

Hermes is the runtime. LPOS documents define behavior.
