# Changelog

## 2.0.0

LPOS is now a complete operating and quality system.

Added:

- Universal Professional Reasoning Standard
- Specialist Quality Routing
- 20 domain craft standards
- Craft-standard routing matrix
- Craft-standard mapping for all specialist charters
- Quality Router
- Independent Reviewer
- System Auditor
- Comprehensive Hermes rebuild prompt
- Repository validation script
- System acceptance checklist

This release extends the quality system beyond copy and UI to research, strategy,
product, engineering, testing, security, finance, legal, data, operations, executive
communication, customer intelligence, planning, model evaluation, documentation,
innovation, platform, and infrastructure.
