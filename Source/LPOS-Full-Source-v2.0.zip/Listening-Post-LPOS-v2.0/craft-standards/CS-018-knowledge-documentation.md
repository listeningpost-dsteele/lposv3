---
    id: CS-018
    title: Knowledge and Documentation Standard
    version: 1.0.0
    status: Accepted
    owner: Listening Post
    ---

    # Knowledge and Documentation Standard


Create one authoritative source for each important concept.

Documentation must be accurate, current, discoverable, structured, versioned, and useful
to its intended reader.

Reject duplicated definitions, stale instructions, unexplained jargon, generated filler,
and documentation that describes plans rather than actual behavior.

Verify links, commands, examples, and ownership.


    ## Required review

    Apply LPOS-026 and LPOS-027. Preserve approved strengths. Use an independent reviewer
    for material production work. Define verification and evidence before completion.
