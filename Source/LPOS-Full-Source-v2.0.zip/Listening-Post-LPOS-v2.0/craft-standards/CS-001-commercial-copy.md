---
    id: CS-001
    title: Commercial Copy Standard
    version: 1.0.0
    status: Accepted
    owner: Listening Post
    ---

    # Commercial Copy Standard


Write for the buyer, not for the model.

Required inputs: audience, current belief, desired belief, problem, outcome, proof,
objections, next action, and tone.

Reject chain-of-thought, internal strategy language, generic AI phrases, unsupported
proof, fake urgency, vague value, and copy that could belong to any company.

Use concrete claims, credible mechanism, real proof, clear hierarchy, and a specific
next action. No em dashes.


    ## Required review

    Apply LPOS-026 and LPOS-027. Preserve approved strengths. Use an independent reviewer
    for material production work. Define verification and evidence before completion.
