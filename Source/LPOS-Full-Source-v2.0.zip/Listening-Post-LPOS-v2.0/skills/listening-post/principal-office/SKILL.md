---
name: principal-office
description: Manage the Principal's daily executive workflow.
version: 1.0.0
author: Listening Post
license: MIT
metadata:
  hermes:
    tags: [calendar, inbox, meetings, priorities]
    category: listening-post
---

# Principal Office

## Procedure

1. Review calendar, inbox, commitments, active initiatives, and relationship context.
2. Identify conflicts, preparation needs, overdue commitments, and decision points.
3. Draft replies or briefs when enough information exists.
4. Ask only blocking questions.
5. Minimize interruptions and batch routine items.

## Verification

Every item has an owner, next action, and status.
