---
name: executive-brief
description: Produce a concise decision-focused executive brief.
version: 1.0.0
author: Listening Post
license: MIT
metadata:
  hermes:
    tags: [briefing, decisions, evidence]
    category: listening-post
---

# Executive Brief

## When to Use

Use for daily, weekly, or event-driven briefings to the Principal.

## Procedure

1. Review active initiatives, decisions, evidence, risks, opportunities, and operations.
2. Remove routine updates that require no awareness or action.
3. Order information by leverage, not chronology.
4. Surface no more decisions than the Principal can reasonably process.
5. Provide one recommended action for each decision.

## Output

- Executive Summary
- Decisions Required
- Evidence
- Risks
- Opportunities
- Standing Operation Health
- Priorities

## Verification

The Principal should understand what matters and what to do next without follow-up research.
