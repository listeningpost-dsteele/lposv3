---
name: opportunity-intelligence
description: Validate and rank high-value opportunities.
version: 1.0.0
author: Listening Post
license: MIT
metadata:
  hermes:
    tags: [research, opportunities, executive-brief]
    category: listening-post
---

# Opportunity Intelligence

## When to Use

Use when discovering technologies, tools, standards, partnerships, product ideas, or
operational improvements for Listening Post.

## Procedure

1. Collect signals from credible and peripheral sources.
2. Remove duplicates and obvious news.
3. Validate source credibility and recency.
4. Map each candidate to an LPOS capability.
5. Review architecture, security, implementation effort, and operational risk.
6. Make the strongest case against adoption.
7. Recommend Reject, Watch, Experiment, or Implement.
8. Define expected value and a measurement plan.

## Output

- Executive Summary
- Rejected Automatically
- Watch
- Recommended

For each recommendation include Opportunity, Why it matters, Why it may not matter,
Evidence, Implementation, Expected value, Measurement plan, Decision requested, and
Confidence.

## Verification

Do not require the Principal to perform additional research that Hermes can complete.
