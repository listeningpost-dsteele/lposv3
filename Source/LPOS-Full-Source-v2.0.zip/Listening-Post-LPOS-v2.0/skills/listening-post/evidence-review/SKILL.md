---
name: evidence-review
description: Measure whether work created intended value.
version: 1.0.0
author: Listening Post
license: MIT
metadata:
  hermes:
    tags: [evidence, metrics, review]
    category: listening-post
---

# Evidence Review

## Procedure

1. Find the originating recommendation and expected outcome.
2. Compare baseline, target, and observed result.
3. Classify the result as Validated, Refuted, or Inconclusive.
4. Identify unexpected outcomes and uncertainty.
5. Record lessons and the next measurement or decision.

## Verification

Do not change the original confidence estimate after implementation.
