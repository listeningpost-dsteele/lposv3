# Listening Post Operating System

LPOS is an open operating system for a single Principal.

It coordinates specialized intelligence, preserves context, runs recurring operations,
and produces measurable evidence.

## Start here

1. Read `lpos/LPOS-000-founding-principles.md`.
2. Read `lpos/LPOS-001-constitution.md`.
3. Load `runtimes/hermes/HERMES-SYSTEM-PROMPT.md` into Hermes.
4. Add the Standing Operations you want Hermes to run.
5. Replace providers without changing LPOS architecture.

## Repository map

- `company/` explains Listening Post.
- `lpos/` contains the constitutional architecture.
- `guilds/` defines domains of expertise.
- `specialists/` defines executable expert roles.
- `standing-operations/` defines recurring work.
- `benchmarks/` defines measurable evaluations.
- `runtimes/hermes/` contains Hermes-ready implementation guidance.

## Core rule

Capabilities are architectural. Providers and runtimes are replaceable.
