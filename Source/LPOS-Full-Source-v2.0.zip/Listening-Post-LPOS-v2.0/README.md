# Listening Post Operating System v2

LPOS v2 combines constitutional architecture, specialist roles, professional reasoning,
domain craft standards, independent review, Standing Operations, and evidence.

## Install or rebuild Hermes

Attach this repository to Hermes and execute:

`HERMES-LPOS-V2-COMPLETE-SYSTEM-PROMPT.md`

Hermes must verify real operation and identify anything that remains unverified.
