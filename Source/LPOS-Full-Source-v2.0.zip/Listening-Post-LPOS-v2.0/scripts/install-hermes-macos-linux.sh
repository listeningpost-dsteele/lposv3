#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${HOME}/.hermes/skills/listening-post"

mkdir -p "$TARGET"
cp -R "${PROJECT_DIR}/skills/listening-post/." "$TARGET/"

echo "Installed LPOS skills to: $TARGET"
echo "Start a new Hermes session, then run:"
echo "  /lpos-core Help me execute my highest-priority project."
echo
echo "Verify with:"
echo "  hermes skills list"
