$ErrorActionPreference = "Stop"
$ProjectDir = Split-Path -Parent $PSScriptRoot
$Target = Join-Path $HOME ".hermes\skills\listening-post"

New-Item -ItemType Directory -Force $Target | Out-Null
Copy-Item -Recurse -Force (Join-Path $ProjectDir "skills\listening-post\*") $Target

Write-Host "Installed LPOS skills to: $Target"
Write-Host "Start a new Hermes session and run /lpos-core."
Write-Host "Verify with: hermes skills list"
