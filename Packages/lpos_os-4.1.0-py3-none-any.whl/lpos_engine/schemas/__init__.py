"""Packaged LPOS runtime schemas."""
