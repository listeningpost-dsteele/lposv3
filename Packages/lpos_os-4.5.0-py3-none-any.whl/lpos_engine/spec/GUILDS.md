# LPOS Guilds


---

## Source: `guilds/GUILD-001-executive.md`

---
id: GUILD-001
title: Executive Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: executive
---

# Executive Guild Charter

## Mission

Own the domain of strategy, prioritization, decision support, and evidence review.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-002-research.md`

---
id: GUILD-002
title: Research Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: research
---

# Research Guild Charter

## Mission

Own the domain of information discovery, source validation, and knowledge synthesis.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-003-engineering.md`

---
id: GUILD-003
title: Engineering Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: engineering
---

# Engineering Guild Charter

## Mission

Own the domain of software design, implementation, testing, and review.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-004-operations.md`

---
id: GUILD-004
title: Operations Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: operations
---

# Operations Guild Charter

## Mission

Own the domain of workflow coordination, operational health, and process improvement.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-005-communications.md`

---
id: GUILD-005
title: Communications Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: communications
---

# Communications Guild Charter

## Mission

Own the domain of writing, editing, briefing, documentation, and presentation.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-006-finance.md`

---
id: GUILD-006
title: Finance Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: finance
---

# Finance Guild Charter

## Mission

Own the domain of financial analysis, forecasting, pricing, and ROI.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-007-security.md`

---
id: GUILD-007
title: Security Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: security
---

# Security Guild Charter

## Mission

Own the domain of threat analysis, permissions, vulnerabilities, and compliance.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-008-legal.md`

---
id: GUILD-008
title: Legal Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: legal
---

# Legal Guild Charter

## Mission

Own the domain of contract, licensing, privacy, regulatory, and legal-risk analysis.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-009-product.md`

---
id: GUILD-009
title: Product Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: product
---

# Product Guild Charter

## Mission

Own the domain of product discovery, requirements, prioritization, and validation.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-010-relationship-intelligence.md`

---
id: GUILD-010
title: Relationship Intelligence Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: relationship-intelligence
---

# Relationship Intelligence Guild Charter

## Mission

Own the domain of contacts, stakeholders, meetings, and relationship health.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-011-customer-intelligence.md`

---
id: GUILD-011
title: Customer Intelligence Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: customer-intelligence
---

# Customer Intelligence Guild Charter

## Mission

Own the domain of customer research, journeys, feedback, and account intelligence.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-012-knowledge-management.md`

---
id: GUILD-012
title: Knowledge Management Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: knowledge-management
---

# Knowledge Management Guild Charter

## Mission

Own the domain of taxonomy, documentation, retrieval, and institutional memory.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-013-intelligence.md`

---
id: GUILD-013
title: Intelligence Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: intelligence
---

# Intelligence Guild Charter

## Mission

Own the domain of patterns, opportunities, risks, scenarios, and strategic assessment.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-014-revenue-operations.md`

---
id: GUILD-014
title: Revenue Operations Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: revenue-operations
---

# Revenue Operations Guild Charter

## Mission

Own the domain of pipeline, forecasting, account progression, and expansion.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-015-platform.md`

---
id: GUILD-015
title: Platform Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: platform
---

# Platform Guild Charter

## Mission

Own the domain of shared services, APIs, identity, observability, and deployment services.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-016-data-intelligence.md`

---
id: GUILD-016
title: Data Intelligence Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: data-intelligence
---

# Data Intelligence Guild Charter

## Mission

Own the domain of metrics, analytics, dashboards, data quality, and lineage.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-017-innovation.md`

---
id: GUILD-017
title: Innovation Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: innovation
---

# Innovation Guild Charter

## Mission

Own the domain of experiments, prototypes, technology evaluation, and portfolio management.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-018-automation.md`

---
id: GUILD-018
title: Automation Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: automation
---

# Automation Guild Charter

## Mission

Own the domain of workflow automation, orchestration, retries, and execution recovery.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-019-infrastructure.md`

---
id: GUILD-019
title: Infrastructure Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: infrastructure
---

# Infrastructure Guild Charter

## Mission

Own the domain of compute, storage, network, capacity, backups, and disaster recovery.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-020-quality-assurance.md`

---
id: GUILD-020
title: Quality Assurance Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: quality-assurance
---

# Quality Assurance Guild Charter

## Mission

Own the domain of acceptance, benchmarks, regression, defects, and release readiness.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-021-personal-office.md`

---
id: GUILD-021
title: Personal Office Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: personal-office
---

# Personal Office Guild Charter

## Mission

Own the domain of calendar, inbox, commitments, meetings, and personal execution.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-022-learning-improvement.md`

---
id: GUILD-022
title: Learning and Improvement Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: learning-improvement
---

# Learning and Improvement Guild Charter

## Mission

Own the domain of retrospectives, lessons learned, and continuous improvement.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-023-integration.md`

---
id: GUILD-023
title: Integration Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: integration
---

# Integration Guild Charter

## Mission

Own the domain of APIs, connectors, synchronization, authentication, and data mapping.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-024-observability.md`

---
id: GUILD-024
title: Observability Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: observability
---

# Observability Guild Charter

## Mission

Own the domain of logs, metrics, traces, dashboards, health, and diagnostics.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-025-ai-strategy.md`

---
id: GUILD-025
title: AI Strategy Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: ai-strategy
---

# AI Strategy Guild Charter

## Mission

Own the domain of AI landscape, adoption, capability assessment, and strategic evaluation.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-026-governance.md`

---
id: GUILD-026
title: Governance Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: governance
---

# Governance Guild Charter

## Mission

Own the domain of constitutional review, standards, compliance, and repository integrity.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-027-model-intelligence.md`

---
id: GUILD-027
title: Model Intelligence Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: model-intelligence
---

# Model Intelligence Guild Charter

## Mission

Own the domain of model benchmarks, prompt quality, routing, context, and inference.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-028-principal-success.md`

---
id: GUILD-028
title: Principal Success Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: principal-success
---

# Principal Success Guild Charter

## Mission

Own the domain of value realization, cognitive load, adoption, and executive experience.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-029-execution.md`

---
id: GUILD-029
title: Execution Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: execution
---

# Execution Guild Charter

## Mission

Own the domain of plans, milestones, blockers, delivery, and completion verification.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-030-principal-intelligence.md`

---
id: GUILD-030
title: Principal Intelligence Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: principal-intelligence
---

# Principal Intelligence Guild Charter

## Mission

Own the domain of preferences, behavior, objectives, and Principal Model quality.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-031-ecosystem.md`

---
id: GUILD-031
title: Ecosystem Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: ecosystem
---

# Ecosystem Guild Charter

## Mission

Own the domain of standards, protocols, open source, partnerships, and interoperability.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-032-runtime.md`

---
id: GUILD-032
title: Runtime Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: runtime
---

# Runtime Guild Charter

## Mission

Own the domain of runtime lifecycle, capability resolution, provider loading, scheduling, recovery, and compatibility.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make
consequential decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-033-provider-intelligence.md`

---
id: GUILD-033
title: Provider Intelligence Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: provider-intelligence
---

# Provider Intelligence Guild Charter

## Mission

Own the domain of provider benchmarking, quality, health, cost, lifecycle, and compatibility.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make
consequential decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-034-capability-engineering.md`

---
id: GUILD-034
title: Capability Engineering Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: capability-engineering
---

# Capability Engineering Guild Charter

## Mission

Own the domain of capability design, composition, versioning, lifecycle, and taxonomy.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make
consequential decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-035-decision-intelligence.md`

---
id: GUILD-035
title: Decision Intelligence Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: decision-intelligence
---

# Decision Intelligence Guild Charter

## Mission

Own the domain of decision preparation, options, tradeoffs, uncertainty, and retrospectives.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make
consequential decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-036-planning.md`

---
id: GUILD-036
title: Planning Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: planning
---

# Planning Guild Charter

## Mission

Own the domain of strategic, operational, project, milestone, dependency, resource, and contingency planning.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make
consequential decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.


---

## Source: `guilds/GUILD-037-design.md`

---
id: GUILD-037
title: Design Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: design
---

# Design Guild Charter

## Mission

Own the domain of web design, product design, brand experience, and visual quality.

## Responsibilities

- Define domain standards.
- Own relevant capabilities.
- Govern specialist charters.
- Maintain benchmarks.
- Review evidence.
- Identify capability gaps.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work.

## Conformance

Specialists in this Guild conform to LPOS-013.

---

## Source: `guilds/GUILD-038-soc2-compliance.md`

---
id: GUILD-038
title: SOC 2 Compliance Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: soc2-compliance
---

# SOC 2 Compliance Guild Charter

## Mission

Own the domain of SOC 2 Type 2 compliance: the codified control framework (AICPA 2017
Trust Services Criteria with the revised 2022 points of focus), the autonomous audit of
everything the system ships, staged remediation of gaps, and the evidence trail that
demonstrates operating effectiveness over the observation period.

## Responsibilities

- Define domain standards: the control catalog in `lpos_engine.compliance.controls`,
  mapped to the Trust Services Criteria.
- Own relevant capabilities: SO-025 (SOC 2 Compliance Audit), the compliance status
  contract, and the compliance report page.
- Govern remediation: every fix for a failing control is built in the staging test
  environment, validated, and adopted into the main system only through exact-action
  Principal approval — never directly.
- Maintain benchmarks: the Type 2 effectiveness record in `compliance/history.jsonl`
  is the guild's evidence ledger; controls must demonstrate effectiveness over the
  window, not merely pass once.
- Review evidence: every control result cites the exact files and values inspected.
- Identify capability gaps: controls that cannot yet be machine-checked (e.g. the
  Privacy category) are recorded as codified-but-unchecked, never silently omitted.

## Boundaries

The Guild defines quality and structure. It does not replace Chip, make consequential
decisions for the Principal, or execute unrelated specialist work. It enforces controls
over the LPOS system itself; it does not issue attestations — a SOC 2 Type 2 report is
issued by an independent CPA firm after an observation period.

## Conformance

Specialists in this Guild conform to LPOS-013. Affiliated specialists: system-auditor,
independent-reviewer, technical-writer.

---

## Source: `guilds/GUILD-039-sentinel-adversarial-assurance.md`

---
id: GUILD-039
title: Sentinel Adversarial Assurance Guild Charter
version: 1.0.0
status: Accepted
owner: Principal
machine:
  type: guild
  slug: sentinel-adversarial-assurance
---

# Sentinel Adversarial Assurance Guild Charter

## Mission

Continuously and independently adversarially test the artifacts Chip creates, identify
security weaknesses before completion or publication, and report prioritized,
verifiable remediation guidance to the Principal.

## Organizational independence

Sentinel is its own organization. It is not part of Chip's creating guild, does not
share the creation context, and does not report to the specialist whose work it tests.
Its Principal-facing destination is the immutable `principal_security_inbox`.

Independence is not trust. Under Constitution Article VIII, every Sentinel assessment,
finding, rule change, report, and remediation proposal begins untrusted. Sentinel may
not approve, certify, publish, enforce, remediate, suppress, downgrade, or close its own
work. The exact raw assessment hash must pass the ordinary LPOS fresh-context
independent adversarial-review process and deterministic structural re-verification
before any finding can affect completion or be presented to the Principal as fact.

## Responsibilities

- Passively scan every persisted Chip artifact revision at creation time.
- Re-scan any revision missed by the event hook through SO-026.
- Use conservative, non-destructive checks for secrets, injection, unsafe execution,
  transport, cryptography, permissions, and agent-control-plane bypasses.
- Bind every finding to the exact task, artifact hash, rule, and redacted evidence hash.
- Attach concrete implementation and verification steps to each finding.
- Stage independently reviewed reports for the Principal and preserve acknowledgement
  as a separate append-only record.
- Fail closed when Sentinel's own independent review is unavailable or rejected.

## Penetration-testing boundary

Continuous operation is read-only and passive by default. Sentinel does not execute
artifacts, open network connections, use credentials, invoke a shell, exploit a target,
create persistence, exfiltrate data, or alter live state. Active penetration testing
requires a separate Principal-approved engagement defining target ownership, scope,
methods, time window, isolation, data handling, stop conditions, and rollback. Active
results remain untrusted and pass the same independent adversarial process.

## Completion policy

A current, hash-bound, trusted Sentinel assessment is required for an artifact to
complete when Sentinel is enabled. Independently reviewed Critical and High findings
block completion and move the task to correction required. Medium, Low, and Info
findings are reported with remediation but are advisory unless the Principal or a
higher policy makes them blocking.

## Boundaries

Sentinel does not replace Chip, the Security Guild, an independent reviewer, a licensed
penetration tester, or an external assessor. It does not claim that an absence of
findings proves security, and it does not issue SOC 2 or other attestations.

## Conformance

Sentinel conforms to LPOS-001 Article VIII, LPOS-026, LPOS-029, LPOS-031, CS-003,
CS-008, and CS-009. Affiliated specialist: SPECIALIST-033. Standing operation: SO-026.


---

## Source: `guilds/GUILD-040-code-testing.md`

---
id: GUILD-040
title: Code Testing Guild Charter
version: 1.0.0
status: Accepted
owner: Listening Post
machine:
  type: guild
  slug: code-testing
---

# Code Testing Guild Charter

## Mission

Prove that code changes are necessary, behaviorally correct, regression-safe,
maintainable, and ready for release.

## Scope

The Guild owns code verification for source code, APIs, scripts, database migrations,
infrastructure-as-code, executable configuration, and build and deployment logic. It
does not review copy, visual quality, market research, or other non-code artifacts.

## Responsibilities

- Classify change criticality.
- Reproduce defects and validate feature gaps through the Need-to-Change Gate.
- Define acceptance criteria in domain language.
- Create executable acceptance specifications and protect the frozen behavior contract.
- Establish characterization baselines for legacy behavior.
- Verify unit, integration, system, property, and invariant tests.
- Run architecture and static fitness checks.
- Evaluate test strength through mutation testing.
- Detect flaky or non-deterministic tests.
- Produce independently verifiable release evidence.
- Veto release when required gates fail.

## Separation of responsibility

Engineering builds code. The Code Testing Guild proves whether the code satisfies its
behavior contract and can be released safely. Quality Assurance evaluates the complete
release across all artifact types. Security owns security judgment; Code Testing executes
and verifies security tests when required.

## Release authority

The Guild may reject or block a code release. It may not approve business scope, deploy
externally, or override the Principal.

## Boundaries

The test gauntlet is the primary verification system; code inspection remains
risk-weighted and supplemental. The Guild does not replace Chip, the Security Guild, an
independent reviewer, or an external assessor, and an absence of findings does not prove
correctness.

## Conformance

The Code Testing Guild conforms to LPOS-013, CS-003, CS-007, CS-008, and CS-009.
Governed specialists: SPECIALIST-034 through SPECIALIST-045. Standing operations: SO-027,
SO-028, and SO-029.
